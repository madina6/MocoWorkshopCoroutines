package com.example.mococoroutineexample


import androidx.compose.ui.graphics.Color
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.*

class ViewModelTimer : ViewModel() {
    private val _timeInSeconds = MutableLiveData(25 * 60)
    val timeInSeconds: LiveData<Int> get() = _timeInSeconds

    private val _isRunning = MutableLiveData(false)
    val isRunning: LiveData<Boolean> get() = _isRunning

    private val _timerColor = MutableLiveData(listOf(Color(0xFF302D31), Color(0xFF7B7B7C)))
    val timerColor: LiveData<List<androidx.compose.ui.graphics.Color>> get() = _timerColor

    private var job: Job? = null

    fun onStart() {
        if (_isRunning.value == true) return
        _isRunning.value = true
        job = CoroutineScope(Dispatchers.Main).launch {
            while (_timeInSeconds.value ?: 0 > 0 && _isRunning.value == true) {
                delay(1000L)
                _timeInSeconds.value = (_timeInSeconds.value ?: 0) - 1
            }
            _isRunning.value = false
        }
    }

    fun onPause() {
        _isRunning.value = false
        job?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        job?.cancel()
    }
}
